// import confetti from "./confetti.js";
import confetti from "https://cdn.skypack.dev/canvas-confetti";

let words = [
    "about",
    "apple",
    "aunt",
    "away",
    "bash",
    "back",
    "before",
    "box",
    "buy",
    "csharp",
    "cake",
    "chair",
    "circle",
    "come",
    "dart",
    "dance",
    "deep",
    "die",
    "drop",
    "elixir",
    "each",
    "empty",
    "ever",
    "eye",
    "fortran",
    "face",
    "fever",
    "firm",
    "fork",
    "golang",
    "gate",
    "gift",
    "gold",
    "gun",
    "haskell",
    "hair",
    "hurt",
    "head",
    "hen",
    "ink",
    "isle",
    "iron",
    "ice",
    "javascript",
    "java",
    "junk",
    "jam",
    "juice",
    "jug",
    "kotlin",
    "kill",
    "knee",
    "knife",
    "know",
    "lua",
    "long",
    "last",
    "light",
    "lame",
    "matlab",
    "moon",
    "milk",
    "mad",
    "meal",
    "native",
    "negro",
    "news",
    "nice",
    "ocaml",
    "off",
    "old",
    "over",
    "oil",
    "python",
    "pain",
    "price",
    "pen",
    "pull",
    "php",
    "quick",
    "queen",
    "queer",
    "rust",
    "rain",
    "rice",
    "run",
    "ruby",
    "repair",
    "spell",
    "scala",
    "skin",
    "swift",
    "story",
    "solidity",
    "soup",
    "true",
    "thin",
    "typescript",
    "tilte",
    "toe",
    "ugly",
    "use",
    "unit",
    "voice",
    "visit",
    "water",
    "wasm",
    "walk",
    "wife",
    "wire",
    "yard",
    "yell",
    "young",
    "zoo",
    "zero",
];

// Dictionary to store hints for each word
let wordHints = {
    about: "Concerning or regarding someone or something.",
    apple: "A round fruit with red or green skin and a crisp white flesh.",
    aunt: "The sister of one's father or mother or the wife of one's uncle.",
    away: "At or to a distance from a particular place, person, or thing.",
    bash: "To strike with a heavy blow.",
    back: "The rear surface of the human body from the shoulders to the hips.",
    before: "During the period of time preceding a particular event, date, or time.",
    box: "A container with a flat base and sides, typically square or rectangular.",
    buy: "Obtain in exchange for payment.",
    csharp: "A programming language developed by Microsoft.",
    cake: "An item of soft sweet food made from a mixture of flour, fat, eggs, sugar, and other ingredients.",
    chair: "A separate seat for one person, typically with a back and four legs.",
    circle: "A round plane figure whose boundary consists of points equidistant from a fixed center.",
    come: "Move or travel toward or into a place thought of as near or familiar.",
    dart: "A small, slender pointed missile that is thrown or shot.",
    dance: "Move rhythmically to music, typically following a set sequence of steps.",
    deep: "Extending far down from the top or surface.",
    die: "Suffer death, typically in a violent, sudden, or untimely way.",
    drop: "Let or make (something) fall vertically.",
    elixir: "A magical or medicinal potion.",
    each: "Used to refer to every one of two or more people or things.",
    empty: "Containing nothing.",
    ever: "At any time.",
    eye: "Each of a pair of globular organs in the head through which people and vertebrate animals see.",
    fortran: "A high-level programming language for numerical and scientific computing.",
    face: "The front part of a person's head from the forehead to the chin.",
    fever: "An abnormally high body temperature.",
    firm: "Having a solid, almost unyielding surface or structure.",
    fork: "An implement with two or more prongs used for lifting food to the mouth.",
    golang: "An open-source programming language developed by Google.",
    gate: "A hinged barrier used to close an opening in a wall, fence, or hedge.",
    gift: "A thing given willingly to someone without payment.",
    gold: "A yellow precious metal, the chemical element of atomic number 79.",
    gun: "A weapon incorporating a metal tube from which bullets, shells, or other missiles are propelled by explosive force.",
    haskell: "A standardized, general-purpose, purely functional programming language.",
    hair: "Any of the fine threadlike strands growing from the skin of humans, mammals, and some other animals.",
    hurt: "Cause physical pain or injury to.",
    head: "The upper part of the human body, or the front or upper part of the body of an animal, typically separated from the rest of the body by a neck.",
    hen: "A female bird, especially of a domestic fowl.",
    ink: "A colored fluid used for writing, drawing, printing, or duplicating.",
    isle: "An island or peninsula, especially a small one.",
    iron: "A strong, hard magnetic silvery-gray metal, the chemical element of atomic number 26.",
    ice: "Frozen water, a brittle transparent crystalline solid.",
    javascript: "A programming language that conforms to the ECMAScript specification.",
    java: "A high-level programming language developed by Sun Microsystems.",
    junk: "Old or discarded articles that are considered useless or of little value.",
    jam: "A sweet spread or preserve made from fruit and sugar boiled to a thick consistency.",
    juice: "The liquid obtained from or present in fruit or vegetables.",
    jug: "A cylindrical container with a handle and a lip, used for holding and pouring liquids.",
    kotlin: "A statically typed programming language developed by JetBrains.",
    kill: "Cause the death of.",
    knee: "The joint between the thigh and the lower leg in humans.",
    knife: "An instrument composed of a blade fixed into a handle, used for cutting or as a weapon.",
    know: "Be aware of through observation, inquiry, or information.",
    lua: "A lightweight, high-level programming language designed for extending applications.",
    long: "Measuring a great distance from end to end.",
    last: "Coming after all others in time or order; final.",
    light: "The natural agent that stimulates sight and makes things visible.",
    lame: "Unable to walk without difficulty as the result of an injury or illness affecting the leg or foot.",
    matlab: "A high-performance language for technical computing.",
    moon: "The natural satellite of the earth, visible (chiefly at night) by reflected light from the sun.",
    milk: "An opaque white fluid rich in fat and protein, secreted by female mammals for the nourishment of their young.",
    mad: "Mentally ill; insane.",
    meal: "Any of the regular occasions in a day when a reasonably large amount of food is eaten.",
    native: "Associated with the country, region, or circumstances of a person's birth.",
    negro: "A member of a dark-skinned group of peoples originally native to Africa south of the Sahara.",
    news: "Newly received or noteworthy information, especially about recent events.",
    nice: "Pleasant; agreeable; satisfactory.",
    ocaml: "A general-purpose programming language with an emphasis on expressiveness and safety.",
    off: "Away from the place in question; to or at a distance.",
    old: "Having lived for a long time; no longer young.",
    over: "Extending directly upward from.",
    oil: "A viscous liquid derived from petroleum, especially for use as a fuel or lubricant.",
    python: "An interpreted, high-level, general-purpose programming language.",
    pain: "Physical suffering or discomfort caused by illness or injury.",
    price: "The amount of money expected, required, or given in payment for something.",
    pen: "An instrument for writing or drawing with ink, typically consisting of a metal nib or ball, or a nylon tip, fitted into a metal or plastic holder.",
    pull: "Exert force on (someone or something) so as to cause movement toward oneself.",
    php: "A server-side scripting language designed primarily for web development.",
    quick: "Done with speed, or showing speed of thought or action.",
    queen: "The female ruler of an independent state, especially one who inherits the position by right of birth.",
    queer: "Strange; odd.",
    rust: "A reddish- or yellowish-brown flaky coating of iron oxide.",
    rain: "Moisture condensed from the atmosphere that falls visibly in separate drops.",
    rice: "The small seed of a cereal grass, widely cultivated as a staple food.",
    run: "Move at a speed faster than a walk, never having both or all the feet on the ground at the same time.",
    ruby: "A precious stone consisting of corundum in color varieties varying from deep crimson or purple to pale rose.",
    repair: "Fix or mend (a thing suffering from damage or a fault).",
    spell: "A word or a combination of words that is considered to have some magical power.",
    scala: "A general-purpose programming language providing support for functional programming and a strong static type system.",
    skin: "The thin layer of tissue forming the natural outer covering of the body of a person or animal.",
    swift: "Moving or capable of moving at great speed.",
    story: "An account of imaginary or real people and events told for entertainment.",
    solidity: "The state or quality of being solid.",
    soup: "A liquid dish, typically made by boiling meat, fish, or vegetables, etc., in stock or water.",
    true: "In accordance with fact or reality.",
    thin: "Having opposite surfaces or sides that are close or relatively close together.",
    typescript: "A strict syntactical superset of JavaScript and adds optional static typing to the language.",
    title: "The name of a book, composition, or other artistic work.",
    toe: "Any of the five digits at the end of the human foot.",
    ugly: "Unpleasant or repulsive, especially in appearance.",
    use: "Take, hold, or deploy (something) as a means of accomplishing a purpose or achieving a result.",
    unit: "An individual thing or person regarded as single and complete but which can also form an individual component of a larger or more complex whole.",
    voice: "The sound produced in a person's larynx and uttered through the mouth, as speech or song.",
    visit: "Go to see and spend time with (someone) socially.",
    water: "A colorless, transparent, odorless liquid that forms the seas, lakes, rivers, and rain and is the basis of the fluids of living organisms.",
    wasm: "WebAssembly is a binary instruction format for a stack-based virtual machine.",
    walk: "Move at a regular pace by lifting and setting down each foot in turn, never having both feet off the ground at once.",
    wife: "A married woman considered in relation to her spouse.",
    wire: "A length or quantity of wire used, for example, for fencing or to carry an electric current.",
    yard: "A unit of linear measure equal to 3 feet (0.9144 meter).",
    yell: "A loud, sharp cry, especially of pain, surprise, or delight.",
    young: "Having lived or existed for only a short time.",
    zoo: "An establishment that maintains a collection of wild animals, typically in a park or gardens, for study, conservation, or display to the public.",
    zero: "No quantity or number; naught; the absence of a quality or quantity."
};

// ============================================================
// Changing height of main div in getRndWord on w=768px if letters exceeds 7
const winWidth = window.innerWidth;

// adding listener to each key
let keyboardBtns = document.querySelectorAll(".keyboard-btn");
keyboardBtns.forEach((key) => {
    key.addEventListener("click", () => play(key.getAttribute("id")));
});

const tries_div = document.querySelector(".tries");
const start_button = document.querySelector("#start");
const main = document.querySelector(".main");
const main_div = document.querySelector(".inner-main");
const img = document.querySelector("#hangman");
const startGame = document.querySelector("#start-game");
let blocks = null;
let dupWord = [];
let word = [];
let tries = 0;
let totalTries = null;
let firstTime = true;

// Modals
const hintModal = document.querySelector("#modal-hint");
const tries0Modal = document.querySelector("#modal-tries0");
const winModal = document.querySelector("#modal-win");
const loseModal = document.querySelector("#modal-lose");
const secretWord = document.querySelector("#secret-word");
const aboutModal = document.querySelector("#modal-about");

// starting script
disableBtns();

start_button.addEventListener("click", () => {
    disableStart();
    enableBtns();
    clearFails();
    clearMainDiv();
    genWrdBlocks();
    setTries();
});

function play(id) {
    if (tries > 0) {
        let match = word.includes(id);
        let res = 1;
        if (match) {
            blocks.forEach((block) => {
                if (
                    !block.classList.contains("visible") &&
                    block.textContent === id &&
                    res >= 1
                ) {
                    block.classList.add("visible");
                    res -= 1;
                }
            });
            word.splice(word.indexOf(id), 1);
        } else if (!match) {
            document.querySelector(`#${id}`).classList.add("fail");
            document.querySelector(`#${id}`).disabled = true;
            decTries();
            document.querySelector(
                ".tries"
            ).innerHTML = `${tries} out of ${totalTries} tries left`;
            setImg();
        }
    }
    winLose();
}

// utility functions

// =========================================

function getRnd(min, max) {
    let step1 = max - min + 1;
    let step2 = Math.random() * step1;
    let result = Math.floor(step2) + min;
    return result;
}

function getRndWord() {
    let word = words[getRnd(0, words.length - 1)].split("");
    if (word.length >= 7 && winWidth <= 768) {
        main.style.height = "140px";
    }
    return word;
}

function genWrdBlocks() {
    word = getRndWord();
    console.log(word);
    dupWord = [...dupWord, ...word];

    // create divs in dom
    word.forEach((letter) => {
        let div = document.createElement("div");
        div.classList.add(`main-block`);
        div.classList.add(`val-${letter}`);
        div.innerHTML = letter;
        main_div.appendChild(div);
    });
    blocks = document.querySelectorAll(".main-block");
}

// =========================================

document.querySelector("#hint").addEventListener("click", hint);
function hint() {
    if (tries > 0) {
        let hintWord = word.join('');
        let hintMessage = wordHints[hintWord];
        if (hintMessage) {
            alert(hintMessage);
        } else {
            alert("Hint not available for this word.");
        }
    }
}

function resetAll() {
    tries = 0;
    document.querySelector(".tries").innerHTML = "tries";
    startGame.innerHTML = "Play Again";
    img.src = "./assets/images/0.png";
    word = [];
    dupWord = [];
    clearFails();
    clearMainDiv();
    enableStart();
}

function clearFails() {
    for (let i = 97; i < 123; i++) {
        document
            .querySelector(`#${String.fromCharCode(i)}`)
            .classList.remove("fail");
    }
}

function clearMainDiv() {
    main_div.innerHTML = "";
}

function setImg() {
    let percent = (tries / totalTries) * 100;
    if (percent > 71.5 && percent <= 87.75) {
        img.src = "./assets/images/1.png";
    } else if (percent > 57.25 && percent <= 71.5) {
        img.src = "./assets/images/2.png";
    } else if (percent > 43 && percent <= 57.25) {
        img.src = "./assets/images/3.png";
    } else if (percent > 28.75 && percent <= 43) {
        img.src = "./assets/images/4.png";
    } else if (percent > 14.5 && percent <= 28.75) {
        img.src = "./assets/images/5.png";
    } else if (percent <= 14.5) {
        img.src = "./assets/images/6.png";
    }
}

function setTries() {
    tries = word.length;
    totalTries = word.length;
    tries_div.innerHTML = `${tries} out of ${totalTries} tries left`;
}

function decTries() {
    tries -= 1;
}

function disableStart() {
    start_button.disabled = true;
    start_button.classList.add("start-fail");
}

function enableStart() {
    start_button.disabled = false;
    start_button.classList.remove("start-fail");
}

function disableBtns() {
    for (let i = 97; i < 123; i++) {
        document.querySelector(`#${String.fromCharCode(i)}`).disabled = true;
    }
    document.querySelector(".hint").disabled = true;
}

function enableBtns() {
    for (let i = 97; i < 123; i++) {
        document.querySelector(`#${String.fromCharCode(i)}`).disabled = false;
    }
    document.querySelector(".hint").disabled = false;
}

function winLose() {
    if (tries === 0) {
        secretWord.innerHTML = `secret word was "${dupWord.join("")}"`;
        openLose();
        setTimeout(() => {
            closeLose();
            resetAll();
            disableBtns();
        }, 2500);
    } else if (
        document.querySelectorAll(".visible").length === dupWord.length
    ) {
        confetti({
            particleCount: 200,
            scalar: 1.175,
            angle: 60,
            gravity: 0.75,
            spread: 70,
            origin: { x: 0 },
        });
        confetti({
            particleCount: 200,
            scalar: 1.175,
            angle: 120,
            gravity: 0.75,
            spread: 70,
            origin: { x: 1 },
        });
        openWin();
        resetAll();
        disableBtns();
        setTimeout(() => {
            closeWin();
        }, 3000);
    }
}

// ================== Modal Functions =====================
// Modal Toggle
function openHint() {
    hintModal.showModal();
}
document.querySelector("#close-hint").addEventListener("click", closeHint);
function closeHint() {
    hintModal.close();
}
function openTries0() {
    tries0Modal.showModal();
}
function closeTries0() {
    tries0Modal.close();
}
function openWin() {
    winModal.showModal();
}
function closeWin() {
    winModal.close();
}
function openLose() {
    loseModal.showModal();
}
function closeLose() {
    loseModal.close();
}
document.querySelector("#open-about").addEventListener("click", () => {
    aboutModal.showModal();
});
document.querySelector("#close-about").addEventListener("click", () => {
    aboutModal.close();
});
// Modal Actions

document
    .querySelector("#take-hint")
    .addEventListener("click", setFirtTimeFalse);
function setFirtTimeFalse() {
    /** on taking hint */
    firstTime = false;
    closeHint();
    hint();
}

function tries0() {
    // when player has not enough tries
    openTries0();
    setTimeout(() => {
        closeTries0();
    }, 1000);
}
