# hangman game

### Check it out [here](https://tangerine-elf-3fca3b.netlify.app/)

---

### Playing the game

> You open it and the interface looks like this

![game-interface](screenshots/1.png)

> You click start game and the game starts

![game-started](screenshots/2.png)

> now you start guessing the word by clicking on alphabets

> Alphabets that are not in the word, turn red by clicking on them. And the completion of hangman starts

![you-have-started-guessing](screenshots/3.png)

> Good New, You can get hints. Bad news, you get that at a cost. As shown below. It first asks you

> If you agree, then it fills random empty block

![taking-hints](screenshots/4.png)

> Interface when you win

![you-won](screenshots/5.png)

> When you lose. (It also shows the word)

![you-lost](screenshots/6.png)

#### So this is how its played. Hope you liked it
